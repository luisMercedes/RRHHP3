﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RRHHPP3.Models;

namespace RRHHPP3.Controllers
{
    public class EMPLEADOesController : Controller
    {
        private RRHHP3Entities1 db = new RRHHP3Entities1();

        // GET: EMPLEADOes
        public ActionResult Index(string searchBy, string search)
        {

            if (searchBy == "Gender")
            {
                return View(db.EMPLEADO.Where(x => x.ESTATUS.StartsWith(search) || search == null).ToList());
            }
            else
            {
                return View(db.EMPLEADO.Where(x => x.FECHA_INGRESO.StartsWith(search) || search == null).ToList());

            }
        }


        //----------------------------------------------------------------------------------------------------------------------
        public ActionResult EmpleadosActivos(String Nombre, String Departamento)
        {
            var provider = from s in db.EMPLEADO select s;

            if (!String.IsNullOrEmpty(Nombre))
            {
                provider = provider.Where(j => j.NOMBRE.Contains(Nombre)).Where(e => e.ESTATUS == "A");
            }
            else if (!String.IsNullOrEmpty(Departamento))
            {
                provider = provider.Where(x => x.DEPARTAMENTO.NOMBRE.Contains(Departamento)).Where(e => e.ESTATUS == "A");
            }
            else
            {
                provider = provider.Where(e => e.ESTATUS == "A");
            }
            return View(provider.ToList());
        }
        //-----------------------------------------------------------------------------------------------------------------------



        // GET: EMPLEADOes/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EMPLEADO eMPLEADO = db.EMPLEADO.Find(id);
            if (eMPLEADO == null)
            {
                return HttpNotFound();
            }
            return View(eMPLEADO);
        }

        // GET: EMPLEADOes/Create
        public ActionResult Create()
        {
            ViewBag.ID_CARGO = new SelectList(db.CARGO, "ID_CARGO", "CARGO1");
            ViewBag.ID_DEPARTAMENTO = new SelectList(db.DEPARTAMENTO, "ID_DEPARTAMENTO", "NOMBRE");
            return View();
        }

        // POST: EMPLEADOes/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID_EMPLEADO,CODIGO_EMPLEADO,NOMBRE,APELLIDO,TELÉFONO,ID_DEPARTAMENTO,ID_CARGO,FECHA_INGRESO,SALARIO,ESTATUS")] EMPLEADO eMPLEADO)
        {
            if (ModelState.IsValid)
            {
                db.EMPLEADO.Add(eMPLEADO);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ID_CARGO = new SelectList(db.CARGO, "ID_CARGO", "CARGO1", eMPLEADO.ID_CARGO);
            ViewBag.ID_DEPARTAMENTO = new SelectList(db.DEPARTAMENTO, "ID_DEPARTAMENTO", "NOMBRE", eMPLEADO.ID_DEPARTAMENTO);
            return View(eMPLEADO);
        }

        // GET: EMPLEADOes/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EMPLEADO eMPLEADO = db.EMPLEADO.Find(id);
            if (eMPLEADO == null)
            {
                return HttpNotFound();
            }
            ViewBag.ID_CARGO = new SelectList(db.CARGO, "ID_CARGO", "CARGO1", eMPLEADO.ID_CARGO);
            ViewBag.ID_DEPARTAMENTO = new SelectList(db.DEPARTAMENTO, "ID_DEPARTAMENTO", "NOMBRE", eMPLEADO.ID_DEPARTAMENTO);
            return View(eMPLEADO);
        }

        // POST: EMPLEADOes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID_EMPLEADO,CODIGO_EMPLEADO,NOMBRE,APELLIDO,TELÉFONO,ID_DEPARTAMENTO,ID_CARGO,FECHA_INGRESO,SALARIO,ESTATUS")] EMPLEADO eMPLEADO)
        {
            if (ModelState.IsValid)
            {
                db.Entry(eMPLEADO).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ID_CARGO = new SelectList(db.CARGO, "ID_CARGO", "CARGO1", eMPLEADO.ID_CARGO);
            ViewBag.ID_DEPARTAMENTO = new SelectList(db.DEPARTAMENTO, "ID_DEPARTAMENTO", "NOMBRE", eMPLEADO.ID_DEPARTAMENTO);
            return View(eMPLEADO);
        }

        // GET: EMPLEADOes/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EMPLEADO eMPLEADO = db.EMPLEADO.Find(id);
            if (eMPLEADO == null)
            {
                return HttpNotFound();
            }
            return View(eMPLEADO);
        }

        // POST: EMPLEADOes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            EMPLEADO eMPLEADO = db.EMPLEADO.Find(id);
            db.EMPLEADO.Remove(eMPLEADO);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
