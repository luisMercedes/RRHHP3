﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RRHHPP3.Models;

namespace RRHHPP3.Controllers
{
    public class PERMISOesController : Controller
    {
        private RRHHP3Entities1 db = new RRHHP3Entities1();

        // GET: PERMISOes
        public ActionResult Index()
        {
            var pERMISO = db.PERMISO.Include(p => p.EMPLEADO);
            return View(pERMISO.ToList());
        }

        // GET: PERMISOes/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PERMISO pERMISO = db.PERMISO.Find(id);
            if (pERMISO == null)
            {
                return HttpNotFound();
            }
            return View(pERMISO);
        }

        // GET: PERMISOes/Create
        public ActionResult Create()
        {
            ViewBag.CODIGO_EMPLEADO3 = new SelectList(db.EMPLEADO, "CODIGO_EMPLEADO", "NOMBRE");
            return View();
        }

        // POST: PERMISOes/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID_PERMISO,CODIGO_EMPLEADO3,DESDE,HASTA,COMENTARIOS")] PERMISO pERMISO)
        {
            if (ModelState.IsValid)
            {
                db.PERMISO.Add(pERMISO);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CODIGO_EMPLEADO3 = new SelectList(db.EMPLEADO, "CODIGO_EMPLEADO", "NOMBRE", pERMISO.CODIGO_EMPLEADO3);
            return View(pERMISO);
        }

        // GET: PERMISOes/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PERMISO pERMISO = db.PERMISO.Find(id);
            if (pERMISO == null)
            {
                return HttpNotFound();
            }
            ViewBag.CODIGO_EMPLEADO3 = new SelectList(db.EMPLEADO, "CODIGO_EMPLEADO", "NOMBRE", pERMISO.CODIGO_EMPLEADO3);
            return View(pERMISO);
        }

        // POST: PERMISOes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID_PERMISO,CODIGO_EMPLEADO3,DESDE,HASTA,COMENTARIOS")] PERMISO pERMISO)
        {
            if (ModelState.IsValid)
            {
                db.Entry(pERMISO).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CODIGO_EMPLEADO3 = new SelectList(db.EMPLEADO, "CODIGO_EMPLEADO", "NOMBRE", pERMISO.CODIGO_EMPLEADO3);
            return View(pERMISO);
        }

        // GET: PERMISOes/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PERMISO pERMISO = db.PERMISO.Find(id);
            if (pERMISO == null)
            {
                return HttpNotFound();
            }
            return View(pERMISO);
        }

        // POST: PERMISOes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PERMISO pERMISO = db.PERMISO.Find(id);
            db.PERMISO.Remove(pERMISO);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
