﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RRHHPP3.Models;

namespace RRHHPP3.Controllers
{
    public class LICENCIAsController : Controller
    {
        private RRHHP3Entities1 db = new RRHHP3Entities1();

        // GET: LICENCIAs
        public ActionResult Index()
        {
            var lICENCIA = db.LICENCIA.Include(l => l.EMPLEADO);
            return View(lICENCIA.ToList());
        }

        // GET: LICENCIAs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            LICENCIA lICENCIA = db.LICENCIA.Find(id);
            if (lICENCIA == null)
            {
                return HttpNotFound();
            }
            return View(lICENCIA);
        }

        // GET: LICENCIAs/Create
        public ActionResult Create()
        {
            ViewBag.CODIGO_EMPLEADO4 = new SelectList(db.EMPLEADO, "CODIGO_EMPLEADO", "NOMBRE");
            return View();
        }

        // POST: LICENCIAs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID_LICECIA,CODIGO_EMPLEADO4,DESDE,HASTA,MOTIVO,COMENTARIOS")] LICENCIA lICENCIA)
        {
            if (ModelState.IsValid)
            {
                db.LICENCIA.Add(lICENCIA);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CODIGO_EMPLEADO4 = new SelectList(db.EMPLEADO, "CODIGO_EMPLEADO", "NOMBRE", lICENCIA.CODIGO_EMPLEADO4);
            return View(lICENCIA);
        }

        // GET: LICENCIAs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            LICENCIA lICENCIA = db.LICENCIA.Find(id);
            if (lICENCIA == null)
            {
                return HttpNotFound();
            }
            ViewBag.CODIGO_EMPLEADO4 = new SelectList(db.EMPLEADO, "CODIGO_EMPLEADO", "NOMBRE", lICENCIA.CODIGO_EMPLEADO4);
            return View(lICENCIA);
        }

        // POST: LICENCIAs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID_LICECIA,CODIGO_EMPLEADO4,DESDE,HASTA,MOTIVO,COMENTARIOS")] LICENCIA lICENCIA)
        {
            if (ModelState.IsValid)
            {
                db.Entry(lICENCIA).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CODIGO_EMPLEADO4 = new SelectList(db.EMPLEADO, "CODIGO_EMPLEADO", "NOMBRE", lICENCIA.CODIGO_EMPLEADO4);
            return View(lICENCIA);
        }

        // GET: LICENCIAs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            LICENCIA lICENCIA = db.LICENCIA.Find(id);
            if (lICENCIA == null)
            {
                return HttpNotFound();
            }
            return View(lICENCIA);
        }

        // POST: LICENCIAs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            LICENCIA lICENCIA = db.LICENCIA.Find(id);
            db.LICENCIA.Remove(lICENCIA);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
