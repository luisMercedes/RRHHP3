﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RRHHPP3.Models;

namespace RRHHPP3.Controllers
{
    public class VACACIONESController : Controller
    {
        private RRHHP3Entities1 db = new RRHHP3Entities1();

        // GET: VACACIONES
        public ActionResult Index()
        {
            var vACACIONES = db.VACACIONES.Include(v => v.EMPLEADO);
            return View(vACACIONES.ToList());
        }

        // GET: VACACIONES/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            VACACIONES vACACIONES = db.VACACIONES.Find(id);
            if (vACACIONES == null)
            {
                return HttpNotFound();
            }
            return View(vACACIONES);
        }

        // GET: VACACIONES/Create
        public ActionResult Create()
        {
            ViewBag.CODIGO_EMPLEADO2 = new SelectList(db.EMPLEADO, "CODIGO_EMPLEADO", "NOMBRE");
            return View();
        }

        // POST: VACACIONES/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID_VACACIONES,CODIGO_EMPLEADO2,DESDE,HASTA,CORRESPONDIENTE,COMENTARIO")] VACACIONES vACACIONES)
        {
            if (ModelState.IsValid)
            {
                db.VACACIONES.Add(vACACIONES);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CODIGO_EMPLEADO2 = new SelectList(db.EMPLEADO, "CODIGO_EMPLEADO", "NOMBRE", vACACIONES.CODIGO_EMPLEADO2);
            return View(vACACIONES);
        }

        // GET: VACACIONES/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            VACACIONES vACACIONES = db.VACACIONES.Find(id);
            if (vACACIONES == null)
            {
                return HttpNotFound();
            }
            ViewBag.CODIGO_EMPLEADO2 = new SelectList(db.EMPLEADO, "CODIGO_EMPLEADO", "NOMBRE", vACACIONES.CODIGO_EMPLEADO2);
            return View(vACACIONES);
        }

        // POST: VACACIONES/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID_VACACIONES,CODIGO_EMPLEADO2,DESDE,HASTA,CORRESPONDIENTE,COMENTARIO")] VACACIONES vACACIONES)
        {
            if (ModelState.IsValid)
            {
                db.Entry(vACACIONES).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CODIGO_EMPLEADO2 = new SelectList(db.EMPLEADO, "CODIGO_EMPLEADO", "NOMBRE", vACACIONES.CODIGO_EMPLEADO2);
            return View(vACACIONES);
        }

        // GET: VACACIONES/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            VACACIONES vACACIONES = db.VACACIONES.Find(id);
            if (vACACIONES == null)
            {
                return HttpNotFound();
            }
            return View(vACACIONES);
        }

        // POST: VACACIONES/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            VACACIONES vACACIONES = db.VACACIONES.Find(id);
            db.VACACIONES.Remove(vACACIONES);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
